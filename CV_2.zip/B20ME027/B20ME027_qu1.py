import cv2
import matplotlib.pyplot as plt
import numpy as np
import os
from sklearn.cluster import KMeans

img2_path, img1_path = "B20ME027\Images\image2.jpg",  "B20ME027\Images\image1.jpg"
img2 = cv2.imread(img2_path, cv2.COLOR_BGR2RGB)
img1 = cv2.imread(img1_path, cv2.COLOR_BGR2RGB)
img1, img2  = cv2.resize(img1,(64,64)),cv2.resize(img2,(64,64))

class RatioCut():
    
    def get_neighbours(self,index,cols,flat_image,lamda,sigma):
        i,j = index//cols,index%cols
        neighbours = []
        weights = []
        for x in range(flat_image.shape[0]):
            i1,j1 = x//cols,x%cols
            if i1==i and j1==j:
                continue
            dij = np.sqrt((i-i1)**2 + (j-j1)**2)
            # if dij<=r:
            neighbours.append(x)
            wij = np.exp(-(((flat_image[index]-flat_image[x])**2) +lamda*(dij**2))/sigma**2)
            weights.append(wij)
        return neighbours, weights

    def compute_adjacency_matrix(self,image, sig_I, sig_d):
        flat_image = image.flatten()
        rows, cols = image.shape
        adjacency_matrix = np.zeros((rows * cols, rows * cols))
        for i in range(flat_image.shape[0]):
            neighbours, weights = self.get_neighbours(i, cols, flat_image, sig_I, sig_d)
            for j in range(len(neighbours)):
                adjacency_matrix[i, neighbours[j]] = weights[j]
                adjacency_matrix[neighbours[j], i] = weights[j]
        return adjacency_matrix

    def compute_degree_matrix(self,adjacency_matrix):
        degree_matrix = np.zeros((adjacency_matrix.shape[0],adjacency_matrix.shape[1]))
        for i in range(adjacency_matrix.shape[0]):
            degree_matrix[i,i] = np.sum(adjacency_matrix[i])
        return degree_matrix

    def compute_laplacian_matrix(self,adjacency_matrix,degree_matrix):
        laplacian_matrix = degree_matrix - adjacency_matrix
        return laplacian_matrix

    def ratio_cut_clustering(self,image, lamda, sigma,k):
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        adjacency_matrix = self.compute_adjacency_matrix(image, lamda, sigma)
        degree_matrix = self.compute_degree_matrix(adjacency_matrix)
        laplacian_matrix = self.compute_laplacian_matrix(adjacency_matrix, degree_matrix)
        eigenvalues, eigenvectors = np.linalg.eig(laplacian_matrix)
        eigenvalues = np.real(eigenvalues)
        eigenvectors = np.real(eigenvectors)
        k_eig_vecs = eigenvectors[:, np.argsort(eigenvalues)[:k]]

        kmeans = KMeans(n_clusters=k).fit(k_eig_vecs)
        labels = kmeans.labels_

        
        segmented_image = np.reshape(labels, img1.shape[:2])

        return segmented_image
    def display_ratio_cut_segmentation(self,image,lamda,sigma,k):
        ratio_cut_image = self.ratio_cut_clustering(image, lamda, sigma, k)
        fig, axs = plt.subplots(1, 2, figsize=(10, 10))
        fig.suptitle(f'Ratio Cut Segmentation with k={k}, lambda={lamda}, sigma={sigma}')
        axs[0].imshow(image)
        axs[0].set_title('Original Image')
        axs[1].imshow(ratio_cut_image)
        axs[1].set_title('Segmented Image')
        plt.show()
    

class KMeansClustering():
    def kmeans_segmentation(self,image, k):
        image_rgb = image.reshape(-1, 3)

        kmeans = KMeans(n_clusters=k)
        labels = kmeans.fit_predict(image_rgb)

        segmented_image = labels.reshape(image.shape[:2])

        return segmented_image

    def display_kmeans_segmentation(self,image,k):
        image = image / 255.0
        segmented_image = self.kmeans_segmentation(image, k=k)

        fig, axs = plt.subplots(1, 2, figsize=(10, 10))
        fig.suptitle(f'KMeans Segmentation with k={k}')
        axs[0].imshow(image)
        axs[0].set_title('Original Image')
        axs[1].imshow(segmented_image)
        axs[1].set_title('Segmented Image')
        plt.show()


def main():
    kmeans = KMeansClustering()
    ratio_cut = RatioCut()
    k1 = 3
    kmeans.display_kmeans_segmentation(img1, k1)
    ratio_cut.display_ratio_cut_segmentation(img1, 1, 50, k1)
    kmeans.display_kmeans_segmentation(img2, k1)
    ratio_cut.display_ratio_cut_segmentation(img2, 6, 30, k1)
    k2= 6
    kmeans.display_kmeans_segmentation(img1, k2)
    ratio_cut.display_ratio_cut_segmentation(img1, 1, 50, k2)
    kmeans.display_kmeans_segmentation(img2, k2)
    ratio_cut.display_ratio_cut_segmentation(img2, 6, 30, k2)


if __name__ == '__main__':
    main()